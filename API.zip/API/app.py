from flask import Flask, jsonify, request

from funcoes_IR import aliquota, parcelaADeduzir, IRPF, INSS

app = Flask(__name__)

@app.route('/IR',methods=['POST'])
def calcula_IR():

    #captura o nome
    nome = request.get_json().get('nome')

    #captura o salario bruto
    sal_bruto = request.get_json().get('salario')

    #captura o salario bruto
    qtd_dep = request.get_json().get('qtd_dep')
    
    #calculo do INSS
    vlINSS  = INSS.calculoINSS(sal_bruto)  

    #captura base de calculo do IR
    baseCalIR = float(sal_bruto)-vlINSS

    #captura aliquota
    aliq = aliquota.capturaAliquota(baseCalIR)

    #captura parcela a deduzir
    parc = parcelaADeduzir.capturaParcela(baseCalIR)

    #captura valor por dependente
    vlDependente = 'R$189,59'

    #captura o valor do IR
    vlIRPF = IRPF.calculoIR(baseCalIR,qtd_dep) 

    #monta o retorno em json
    retorno = {"Nome":nome,'Aliquota':aliq,'Parcela a Deduzir':parc,'Valor por dependente':vlDependente,'Valor do IR':round(vlIRPF,2)}
    #retorno = {'Aliquota':aliq,'Parcela a Deduzir':parc,'Valor por dependente':vlDependente}

    #devls.append(dados)
    return jsonify(retorno),201
     
if __name__ == '__main__':
    app.run(debug=True)