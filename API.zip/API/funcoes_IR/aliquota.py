#captura aliquota para exibição
def capturaAliquota(sal_bruto):
    aliquota = ''
    if float(sal_bruto) <= 1903.98:
        aliquota = '-'
    elif (float(sal_bruto) >= 1903.99) and (float(sal_bruto) <= 2826.65):
        aliquota = '7,5%'
    elif (float(sal_bruto) >= 2826.66) and (float(sal_bruto) <= 3751.05):
        aliquota = '15%'
    elif (float(sal_bruto) >= 3751.06) and (float(sal_bruto) <= 4664.69):
        aliquota = '22,5%'
    else: 
        aliquota = '27,5%'    
    return aliquota

#captura aliquota para calculo
def capturaAliquotaIR(baseCalIR):
    aliquota = 0.0
    if baseCalIR <= 1903.98:
        aliquota = 0.0
    elif (baseCalIR >= 1903.99) and (baseCalIR <= 2826.65):
        aliquota = 0.075
    elif (baseCalIR >= 2826.66) and (baseCalIR <= 3751.05):
        aliquota = 0.15
    elif (baseCalIR >= 3751.06) and (baseCalIR <= 4664.69):
        aliquota = 0.225
    else: 
        aliquota = 0.275    
    return aliquota
