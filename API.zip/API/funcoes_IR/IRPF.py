from funcoes_IR import INSS, aliquota, parcelaADeduzir

def calculoIR(baseCalIR,qtd_dep):
    #vlIR = 0.0

    #calculo das parcelas dos dependentes
    if qtd_dep !=0:
        vlDependentes =  float(qtd_dep)*189.59
    
    #aliquota do IR
    aliquotaIR    = aliquota.capturaAliquotaIR(baseCalIR)
    
    #parcela a deduzir do IR
    parcDeduzir   = parcelaADeduzir.capturaParcelaIR(baseCalIR)

    if baseCalIR <= 1903.98:
        return 'Isento'
    elif qtd_dep>0:
        vlIR = ((baseCalIR-vlDependentes)*aliquotaIR)-parcDeduzir
    else:
        vlIR = (baseCalIR*aliquotaIR)-parcDeduzir    

    return vlIR