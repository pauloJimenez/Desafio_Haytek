#captura parcela a deduzir para exibicao
def capturaParcela(sal_bruto):
    parcela = ''
    if float(sal_bruto) <= 1903.98:
        parcela = '-'
    elif (float(sal_bruto) >= 1903.99) and (float(sal_bruto) <= 2826.65):
        parcela = 'R$ 142,80'
    elif (float(sal_bruto) >= 2826.66) and (float(sal_bruto) <= 3751.05):
        parcela = 'R$ 354,80'
    elif (float(sal_bruto) >= 3751.06) and (float(sal_bruto) <= 4664.69):
        parcela = 'R$ 636,13'
    else: 
        parcela = 'R$ 869,36'    
    return parcela

#captura parcela a deduzir para calculo do IR
def capturaParcelaIR(baseCalIR):
    parcela = 0.0
    if baseCalIR <= 1903.98:
        parcela = 0.0
    elif (baseCalIR >= 1903.99) and (baseCalIR <= 2826.65):
        parcela = 142.80
    elif (baseCalIR >= 2826.66) and (baseCalIR <= 3751.05):
        parcela = 354.80
    elif (baseCalIR >= 3751.06) and (baseCalIR <= 4664.69):
        parcela = 636.13
    else: 
        parcela = 869.36    
    return parcela
    